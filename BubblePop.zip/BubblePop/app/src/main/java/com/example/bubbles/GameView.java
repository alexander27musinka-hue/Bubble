package com.example.bubbles;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.Random;

public class GameView extends View {
    static class B { float x, y, r, vy, ph, hue; int type; } // type: 0 обычный, 1 золотой, 2 бомба
    static class P { float x, y, vx, vy, life; int color; }

    final ArrayList<B> bs = new ArrayList<>();
    final ArrayList<P> ps = new ArrayList<>();
    final Random rnd = new Random();
    final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint bg = new Paint();
    final SharedPreferences sp;
    final float d;
    float spawn, t, overT, comboT, shake;
    int score, lives = 3, best, combo, w, h;
    boolean over;
    long last = System.nanoTime();

    public GameView(Context c) {
        super(c);
        sp = c.getSharedPreferences("g", 0);
        best = sp.getInt("best", 0);
        d = getResources().getDisplayMetrics().density;
        paint.setTypeface(Typeface.DEFAULT_BOLD);
    }

    @Override protected void onSizeChanged(int nw, int nh, int ow, int oh) {
        w = nw; h = nh;
        bg.setShader(new LinearGradient(0, 0, 0, h, 0xFF12082E, 0xFF1F7A8C, Shader.TileMode.CLAMP));
    }

    float bx(B b) { return b.x + (float) Math.sin(t * 2 + b.ph) * b.r * 0.3f; }

    void reset() {
        bs.clear(); ps.clear();
        score = 0; lives = 3; combo = 0; over = false; spawn = 0;
    }

    void update(float dt) {
        t += dt; comboT += dt; shake = Math.max(0, shake - dt * 3);
        if (over) { overT += dt; }
        else {
            spawn -= dt;
            if (spawn <= 0) {
                spawn = Math.max(0.25f, 0.9f - score * 0.012f);
                B b = new B();
                float roll = rnd.nextFloat();
                b.type = roll < 0.10f ? 1 : (roll < 0.20f + Math.min(0.1f, score * 0.002f) ? 2 : 0);
                b.r = (b.type == 1 ? 26 : 34 + rnd.nextInt(28)) * d;
                b.x = b.r + rnd.nextFloat() * (w - 2 * b.r);
                b.y = h + b.r;
                b.vy = h * (0.17f + Math.min(0.3f, score * 0.003f) + rnd.nextFloat() * 0.1f) * (b.type == 1 ? 1.6f : 1f);
                b.ph = rnd.nextFloat() * 6.28f;
                b.hue = rnd.nextFloat() * 360;
                bs.add(b);
            }
        }
        for (int i = bs.size() - 1; i >= 0; i--) {
            B b = bs.get(i);
            b.y -= b.vy * dt;
            if (b.y + b.r < 0) {
                bs.remove(i);
                if (b.type != 2 && !over) { lives--; combo = 0; shake = 1; if (lives <= 0) endGame(); }
            }
        }
        for (int i = ps.size() - 1; i >= 0; i--) {
            P p = ps.get(i);
            p.life -= dt * 1.6f;
            p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 900 * d * dt;
            if (p.life <= 0) ps.remove(i);
        }
    }

    void endGame() {
        over = true; overT = 0;
        if (score > best) { best = score; sp.edit().putInt("best", best).apply(); }
    }

    int colorOf(B b) {
        return b.type == 1 ? 0xFFFFD54F : b.type == 2 ? 0xFF333333 : Color.HSVToColor(new float[]{b.hue, 0.55f, 1f});
    }

    void burst(float x, float y, int color) {
        for (int i = 0; i < 16; i++) {
            P p = new P();
            double a = rnd.nextDouble() * Math.PI * 2;
            float s = (150 + rnd.nextInt(350)) * d;
            p.x = x; p.y = y; p.vx = (float) Math.cos(a) * s; p.vy = (float) Math.sin(a) * s - 200 * d;
            p.life = 1; p.color = color;
            ps.add(p);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() != MotionEvent.ACTION_DOWN && e.getActionMasked() != MotionEvent.ACTION_POINTER_DOWN) return true;
        if (over) { if (overT > 0.7f) reset(); return true; }
        int idx = e.getActionIndex();
        float tx = e.getX(idx), ty = e.getY(idx);
        for (int i = bs.size() - 1; i >= 0; i--) {
            B b = bs.get(i);
            float dx = tx - bx(b), dy = ty - b.y, rr = b.r * 1.25f;
            if (dx * dx + dy * dy <= rr * rr) {
                bs.remove(i);
                burst(bx(b), b.y, colorOf(b));
                if (b.type == 2) {
                    lives--; combo = 0; shake = 1;
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    if (lives <= 0) endGame();
                } else {
                    combo = comboT < 1.2f ? combo + 1 : 1;
                    comboT = 0;
                    score += (b.type == 1 ? 5 : 1) + combo / 5;
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                }
                break;
            }
        }
        return true;
    }

    @Override protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        update(dt);

        c.save();
        if (shake > 0) c.translate((rnd.nextFloat() - 0.5f) * 20 * d * shake, (rnd.nextFloat() - 0.5f) * 20 * d * shake);
        c.drawRect(-50, -50, w + 50, h + 50, bg);

        for (B b : bs) {
            float x = bx(b);
            int col = colorOf(b);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(col); paint.setAlpha(b.type == 2 ? 230 : 110);
            c.drawCircle(x, b.y, b.r, paint);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2.5f * d);
            paint.setColor(b.type == 2 ? 0xFFFF3B30 : col); paint.setAlpha(240);
            c.drawCircle(x, b.y, b.r, paint);
            if (b.type == 2) {
                float k = b.r * 0.4f; paint.setStrokeWidth(4 * d);
                c.drawLine(x - k, b.y - k, x + k, b.y + k, paint);
                c.drawLine(x - k, b.y + k, x + k, b.y - k, paint);
            } else {
                paint.setStyle(Paint.Style.FILL); paint.setColor(Color.WHITE); paint.setAlpha(160);
                c.drawCircle(x - b.r * 0.35f, b.y - b.r * 0.35f, b.r * 0.2f, paint);
            }
        }
        paint.setStyle(Paint.Style.FILL);
        for (P p : ps) {
            paint.setColor(p.color); paint.setAlpha((int) (255 * Math.max(0, p.life)));
            c.drawCircle(p.x, p.y, 5 * d * p.life + 1, paint);
        }

        paint.setColor(Color.WHITE); paint.setAlpha(255);
        paint.setTextAlign(Paint.Align.LEFT); paint.setTextSize(40 * d);
        c.drawText(String.valueOf(score), 20 * d, 80 * d, paint);
        paint.setTextSize(14 * d); paint.setAlpha(170);
        c.drawText("Рекорд: " + best, 22 * d, 100 * d, paint);
        paint.setAlpha(255); paint.setTextSize(30 * d); paint.setTextAlign(Paint.Align.RIGHT);
        StringBuilder hearts = new StringBuilder();
        for (int i = 0; i < 3; i++) hearts.append(i < lives ? "♥" : "♡");
        paint.setColor(0xFFFF6B81);
        c.drawText(hearts.toString(), w - 20 * d, 76 * d, paint);

        paint.setTextAlign(Paint.Align.CENTER);
        if (!over && combo >= 3 && comboT < 1.2f) {
            paint.setColor(0xFFFFD54F); paint.setTextSize(26 * d);
            c.drawText("Комбо x" + combo + "!", w / 2f, 140 * d, paint);
        }
        if (over) {
            paint.setColor(0xAA000000); c.drawRect(0, 0, w, h, paint);
            paint.setColor(Color.WHITE); paint.setTextSize(42 * d);
            c.drawText("Игра окончена", w / 2f, h / 2f - 40 * d, paint);
            paint.setTextSize(28 * d);
            c.drawText("Счёт: " + score + (score >= best && score > 0 ? "  🏆" : ""), w / 2f, h / 2f + 10 * d, paint);
            paint.setTextSize(18 * d); paint.setAlpha(overT > 0.7f ? 255 : 80);
            c.drawText("Нажми, чтобы сыграть снова", w / 2f, h / 2f + 70 * d, paint);
        } else if (score == 0 && bs.size() < 3) {
            paint.setColor(Color.WHITE); paint.setAlpha(200); paint.setTextSize(18 * d);
            c.drawText("Лопай пузыри! Золотые = +5, чёрные не трогай", w / 2f, h - 60 * d, paint);
        }
        c.restore();
        postInvalidateOnAnimation();
    }
}
